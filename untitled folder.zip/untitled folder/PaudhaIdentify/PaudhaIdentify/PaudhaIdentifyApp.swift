//
//  PaudhaIdentifyApp.swift
//  PaudhaIdentify
//
//  Created by SHHH!! private on 24/03/24.
//

import SwiftUI

@main
struct PaudhaIdentifyApp: App {
    var body: some Scene {
        WindowGroup {
            IdentifyView()
        }
    }
}
