//
//  diagnosePaudhaApp.swift
//  diagnosePaudha
//
//  Created by SHHH!! private on 26/03/24.
//

import SwiftUI

@main
struct diagnosePaudhaApp: App {
    var body: some Scene {
        WindowGroup {
            DiagnoseView()
        }
    }
}
